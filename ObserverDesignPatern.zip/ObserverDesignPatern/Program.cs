﻿using System;
using System.IO;
using System.Text;
using Microsoft.Extensions.Logging;

namespace ObserverPatternExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Subject subject = new Subject("Laptop", "1000 USD", "In Stock");
            Observer observer1 = new Observer("Observer 1");
            Observer observer2 = new Observer("Observer 2");

            observer1.AddSubject(subject);
            observer2.AddSubject(subject);

            subject.SetAvailability("Available for Pre-order");

            // Example of logging
            ILogger<Program> logger = new FileLogger<Program>("log.txt");
            logger.LogInformation("Program started.");
        }

        class FileLogger<T> : FileStream, ILogger<T>
        {
            public FileLogger(string path)
                : base(path, FileMode.Append) { }

            public IDisposable BeginScope<TState>(TState state)
            {
                throw new NotImplementedException();
            }

            public bool IsEnabled(LogLevel logLevel)
            {
                return true;
            }

            public void Log<TState>(
                LogLevel logLevel,
                EventId eventId,
                TState state,
                Exception exception,
                Func<TState, Exception, string> formatter
            )
            {
                byte[] messageByteArray = new UTF8Encoding(true).GetBytes(state.ToString() + "\n");

                Write(messageByteArray, 0, messageByteArray.Length);
                Flush();
            }
        }
    }
}
