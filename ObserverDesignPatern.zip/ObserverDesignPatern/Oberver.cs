using System;

namespace ObserverPatternExample
{
    public class Observer : IObserver
    {
        private string ObserverName { get; set; }

        public Observer(string observerName)
        {
            ObserverName = observerName;
        }

        public void AddSubject(ISubject subject)
        {
            subject.Attach(this);
        }

        public void RemoveSubject(ISubject subject)
        {
            subject.Detach(this);
        }

        public void Update(string data)
        {
            Console.WriteLine($"{ObserverName} notified with data: {data}");
        }
    }
}
