namespace ObserverPatternExample
{
    public interface IObserver
    {
        void Update(string data);
    }
}
