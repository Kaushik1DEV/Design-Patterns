using System;
using System.Collections.Generic;

namespace ObserverPatternExample
{
    public class Subject : ISubject
    {
        private List<IObserver> observers = new List<IObserver>();

        private string ProductName { get; set; }
        private string ProductPrice { get; set; }
        private string ProductAvailability { get; set; }

        public Subject(string productName, string productPrice, string productAvailability)
        {
            ProductName = productName;
            ProductPrice = productPrice;
            ProductAvailability = productAvailability;
        }

        public void SetAvailability(string availability)
        {
            ProductAvailability = availability;
            Console.WriteLine($"Product availability updated to: {ProductAvailability}");
            Notify();
        }

        public string GetAvailability()
        {
            return ProductAvailability;
        }

        public void Attach(IObserver observer)
        {
            observers.Add(observer);
        }

        public void Detach(IObserver observer)
        {
            observers.Remove(observer);
        }

        public void Notify()
        {
            foreach (var observer in observers)
            {
                observer.Update(ProductAvailability);
            }
        }
    }
}
